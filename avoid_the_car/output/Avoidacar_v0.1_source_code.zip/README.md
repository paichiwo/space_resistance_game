# 1.AVOIDACAR

# How it began:
This is first game I have developed myself using pygame framework. 
The most difficult part was to loop the background endlessly so it gives a illusion of motion.
With that done it was only fun to experiment with pygame and I actually done made more 
calculations that were neeeded for this game like counting time or having car accelerate with momentum.
I finally decided about all the rules in the game and got rid of some unnecessary functions, 
however save them in a folder to be used in future games.

# Let's play:
Well, you start on the road driving at 70km/h.
Every 1 km of distance gained rises your level and speed.
There's 10 level in total and when you beat 10th level game crashes :) 
When you bump in to other cars there's basic bump behaviour implemented.
You have a health bar, that decreases with every bump and when it reaches 0 you'll see the game over screen.

# Installation:


![](img/screenshot/1.png)

